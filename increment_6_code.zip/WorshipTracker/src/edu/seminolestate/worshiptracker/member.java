package edu.seminolestate.worshiptracker;

public class member {
	//MEMBER VARIABLES:
		private int Member_ID;
		private String LastName;
		private String FirstName; 
		private String Address;
		private String City;
		private int Phone;
		private int Role;
		
		//CONSTRUCTOR:
		public member(int newMember_ID, String newLastName, String newFirstName, String newAddress, String newCity, int newPhone, int newRole) {
			this.Member_ID = newMember_ID;
			this.LastName = newLastName;
			this.FirstName = newFirstName;
			this.Address = newAddress;
			this.City = newCity;
			this.Phone = newPhone;
			this.Role = newRole;
		}
		
		public member(String newLastName, String newFirstName, String newAddress, String newCity, int newPhone, int newRole) {
			this.LastName = newLastName;
			this.FirstName = newFirstName;
			this.Address = newAddress;
			this.City = newCity;
			this.Phone = newPhone;
			this.Role = newRole;
		}

		//GETTERS AND SETTERS:
		public int getMember_ID() {
			return Member_ID;
		}
		public void setMember_ID(int member_ID) {
			Member_ID = member_ID;
		}
		public String getLastName() {
			return LastName;
		}
		public void setLastName(String lastName) {
			LastName = lastName;
		}
		public String getFirstName() {
			return FirstName;
		}
		public void setFirstName(String firstName) {
			FirstName = firstName;
		}
		public String getAddress() {
			return Address;
		}
		public void setAddress(String address) {
			Address = address;
		}
		public String getCity() {
			return City;
		}
		public void setCity(String city) {
			City = city;
		}
		public int getPhone() {
			return Phone;
		}
		public void setPhone(int phone) {
			Phone = phone;
		}
		public int getRole() {
			return Role;
		}
		public void setRole(int role) {
			Role = role;
		}

		//ToString METHOD:
		@Override
		public String toString() {
			return "member [Member_ID=" + Member_ID + ", LastName=" + LastName + ", FirstName=" + FirstName
					+ ", Address=" + Address + ", City=" + City + ", Phone=" + Phone + ", Role=" + Role
					+ "]";
		} 
				
}
