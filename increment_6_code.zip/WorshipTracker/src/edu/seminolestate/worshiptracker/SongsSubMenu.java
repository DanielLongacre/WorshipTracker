package edu.seminolestate.worshiptracker;

import java.util.ArrayList;
import java.util.Scanner;

public class SongsSubMenu {
		
	private static Scanner scanner = new Scanner(System.in);
	
	public static void  main() {
		
		int subMenu1Choice = 0;
		
		//SUBMENU OPTIONS
		while (subMenu1Choice != 5) { // continue to loop until user enters 3 (exit)
			subMenu1Choice = getSongsSubMenuChoice();
			switch (subMenu1Choice) {
			case 1: //ADD SONG
				SongDAO songDAO = new SongDAO();//call constructor to create DB connection
				
				//Prompt for the Song info
				String userSong_Title = getString("Enter Song Title: ");
				String userComposer = getString("Enter Composer: ");
				String userSong_Key = getString("Enter Song Key: ");
				double userLength = getDouble("Enter Song Length: ");
				
				songs song = new songs(userSong_Title, userComposer, userSong_Key, userLength);
				
				//Check to see if Song Exists
				songs searchExists = songDAO.findSong(userSong_Title);
				if (searchExists != null) {
					System.out.println("\nThat Song already exists");
					break;
				}
				//Add song to database
				songDAO.insertSong(song);
				
				//Confirm song added
				System.out.println("\nNew Song added!");
				break;
			case 2: //DELETE SONG	
				SongDAO songDAOshow = new SongDAO(); //Call constructor to create DB connection
				SongDAO songDelete = new SongDAO(); //Call constructor to create DB connection
				
				//Display all songs so the user can choose the appropriate Song Title to delete
				ArrayList<songs> songList = (ArrayList<songs>)songDAOshow.selectAllSongs();
				if (songList != null) {
					System.out.println("\nSong List");
					displayAllFormatted(songList);
				} else {
					System.out.println("Currently, there are no songs");
				}
				
				//Ask user to choose Song to delete by Song Title
				String userDeleteSongTitle = getString("\n\nEnter Song Title to delete: ");
				//Check to see if Song Exists
				songs searchForSong = songDAOshow.findSong(userDeleteSongTitle);
				if (searchForSong == null) {
					System.out.println("That Song was not found");
					break;
				}
				
				songDelete.deleteSong(userDeleteSongTitle);
				System.out.println("\nSong Deleted!\n");
				break;
			case 3: //CHANGE SONG
				SongDAO songDAOchange = new SongDAO();
				SongDAO songDAOList = new SongDAO();
				
				//Display all songs so the user can choose the appropriate Song Title to delete
				ArrayList<songs> songList2 = (ArrayList<songs>)songDAOList.selectAllSongs();
				if (songList2 != null) {
					System.out.println("\nSong List");
					displayAllFormatted(songList2);
				} else {
					System.out.println("Currently, there are no songs");
				}
				
				String searchSong_Title = getString("\n\nEnter Song Title for the song to update: ");
				//Check to see if Song exists
				songs searchSongs = songDAOchange.findSong(searchSong_Title);
				if ( searchSongs == null) {
					System.out.println("That Song was not found");
					break;
				}
				//else...
				//CHOOSE WHICH FIELDS TO UPDATE
				
				//Composer
				System.out.println("Current Composer is " + searchSongs.getComposer() + 
						". Enter new Composer or Enter key to skip.");
				String newComposer = scanner.nextLine();
				if (newComposer.length() > 0) {
					searchSongs.setComposer(newComposer);
				} //else leave original value in place
				
				//Song Key
				System.out.println("Current Song_Key is " + searchSongs.getSong_Key() + 
						". Enter new Song_Key or Enter key to skip.");
				String newKey = scanner.nextLine();
				if (newKey.length() > 0) {
					searchSongs.setSong_Key(newKey);
				} //else leave original value in place
				
				//Length
				System.out.println("Current Length is " + searchSongs.getLength() + 
						". Enter new Length or Enter key to skip.");
				String newLength = scanner.nextLine();
				if (newLength.length() > 0) {
					try {
						double newLengthint = Double.parseDouble(newLength);
						searchSongs.setLength(newLengthint);
					} catch (NumberFormatException e) {
						System.out.println("Invalid Entry. Please enter length of song in #.## format");
						break;
						}
				} else {
					searchSongs.setLength(searchSongs.getLength());
				}
				
				boolean isSuccessful = songDAOchange.updateSong(searchSongs);
				if (isSuccessful) {
					System.out.println("\nSong Updated!");
				} else { 
					System.out.println("\nThat Song was not Updated.");
				}
				
				break;
			case 4: //SELECT MEMBER
				SongDAO songDAOselect = new SongDAO(); //Call constructor to create DB connection
				
				String userSelectSongTitle = getString("\n\nEnter Song Title to display: ");
				//Check to see if Song Exists
				songs songSearch = songDAOselect.findSong(userSelectSongTitle);
				if (songSearch == null) {
					System.out.println("That Song was not found");
					break;
				} else {
					displaySong(songSearch);
				}
				break;
			case 5: //EXIT
				break;
			default: //Invalid menu choice was entered
				System.out.println("Invalid menu choice. Choose from the options displayed.\n");
				break;
			}
		}
	}
	
//MENU_______________________________________________________________________________________________________________
		public static int getSongsSubMenuChoice() {
			int userResponse = 0;

			String userInput;
			System.out.println("\nSong Menu: ");
			System.out.println("1. Add Song");
			System.out.println("2. Delete Song");
			System.out.println("3. Change Song");
			System.out.println("4. Select Song");
			System.out.println("5. Exit to Main Menu");
			userInput = scanner.nextLine();
			if (userInput == null || userInput.equals("")) {// if no input ...
				return 99;
			}
			userResponse = Integer.parseInt(userInput);
			return userResponse;
		}
		
//INPUT AND ERRORS_______________________________________________________________________________________________________________	
	//FOR STRING ENTRY  
		public static String getString(String prompt) {
			String input = null;
			while (input == null) {
				System.out.print(prompt);
				input = scanner.nextLine();
				if (input == null || input == "") {
					System.out.println("Invalid Entry. Please reenter.");
					System.out.print(prompt);
					input = scanner.nextLine();
				}
			}
			return input;
		}		
	
	//FOR MEMBER ROLE INTEGER ENTRY
		public static int getInt(String prompt) {
			int userInt = 0;
			do {
				try {
					System.out.print(prompt);
					String userValue = scanner.nextLine();
					userInt = Integer.parseInt(userValue);
					if (userInt <= 0) {
						System.out.println("Value must be greater than 0. Please reenter.");
						}
					}
				catch (NumberFormatException e) {
					System.out.println("Invalid Entry. Value must be greater than 0. Please reenter.");
					}
			} while (userInt <= 0);

			return userInt;
		}			

	//FOR MEMBER ROLE DOUBLE ENTRY
			public static double getDouble(String prompt) {
				double userDouble = 0;
				do {
					try {
						System.out.print(prompt);
						String userValue = scanner.nextLine();
						userDouble = Double.parseDouble(userValue);
						if (userDouble <= 0) {
							System.out.println("Value must be greater than 0. Please reenter.");
							}
						}
					catch (NumberFormatException e) {
						System.out.println("Invalid Entry. Value must be greater than 0. Please reenter.");
						}
				} while (userDouble <= 0);

				return userDouble;
			}
//DISPLAY SONG_______________________________________________________________________________________________________________
			public static void displaySong(songs songs) {
				System.out.println("\n*************************");
				System.out.println(songs.getSong_Title());
				System.out.println(songs.getComposer());
				System.out.println(songs.getSong_Key() + ", " + songs.getLength());
				System.out.println(songs.getTotal_Count());
				System.out.println("*************************\n");
			}				
			
//DISPLAY ALL SONGS_______________________________________________________________________________________________________________
			/*
			 * Method displays all the Role rows from the DB. The print method is used to space
			 * the data into columns with heading.
			 */
			public static void displayAllFormatted (ArrayList<songs> songList) {
				System.out.printf("\n%-30s %-25s %-10s %-10s", 
						"Song_Title", "Composer", "Song_Key", "Length");
				System.out.printf("\n%-30s %-25s %-10s %-10s", 
						"----------------", "----------------", "---------", "---------");
				for (songs aSong : songList) {
					System.out.printf("\n%-30s %-25s %-10s %-10s", 
							aSong.getSong_Title(),
							aSong.getComposer(),
							aSong.getSong_Key(),
							aSong.getLength());
				}
			}			
			
}
