package edu.seminolestate.worshiptracker;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.Collection;
import java.util.List;


/*
 * This class is used implement CRUD (Create, Retrieve (query), Update, Delete) actions
 *  on a database. DAO stands for Data Access Object.
 *  How to use this class:
 *  1. 	Create a WorshipDAO object;
 *  2.	Use the WorshipDAO object to call the appropriate CRUD method:
 *  	a.	Use insertMember to add a row to the Member table;
 *  	b. 	Use deleteMember to remove a row from the Member table;
 *  	c.	Use updateMember to change a row in the Member table;
 *  	d. 	Use findMember to query (retrieve) a row from the Member table;
 *  	e.	Use selectAllMembers to query (retrieve) all rows from the Member table;
 */
public class WorshipDAO {

	private static Connection connection;
	
	public WorshipDAO(){
		connection = DbConnection.getConnection();
	}

	 /*
	  * insert new member row;
	  * parameter (member) contains all the data for the new DB row;
	  * Return true on success, false on failure;
	  */
//INSERT MEMBER_______________________________________________________________________________________________________
	public boolean insertMember(member member) {

		boolean result = false; 
		String sqlStatement = new String("INSERT INTO worship_member (LastName, FirstName, Address, City, Phone, Role) VALUES (?, ?, ?, ?, ?, ?)"); 
		PreparedStatement prepSqlStatement = null;
		try {
			prepSqlStatement = connection.prepareStatement(sqlStatement);
			prepSqlStatement.setString(1, member.getLastName());
			prepSqlStatement.setString(2, member.getFirstName());
			prepSqlStatement.setString(3, member.getAddress());
			prepSqlStatement.setString(4, member.getCity());
			prepSqlStatement.setInt(5, member.getPhone());
			prepSqlStatement.setInt(6, member.getRole());
			int rowCount = prepSqlStatement.executeUpdate();
			if (rowCount != 1){
				result =  false; 
			}
			else {
					result = true;
			}
		} catch (SQLException ex) {
			// TODO Auto-generated catch block
			ex.printStackTrace();
			result =  false;
		}	
		return result; 
	}
	
	 /*
	  * delete (remove) existing member row;
	  * the parameter (member) contains the primary key value used to select the specific
	  * rows to delete;
	  * Return true on success, false on failure;
	  */
//DELETE MEMBER_______________________________________________________________________________________________________	
	public boolean deleteMember(int memberID) {

		boolean result = false; 
		String sqlStatement = new String("DELETE FROM worship_member WHERE Member_ID = ?"); 
		PreparedStatement prepSqlStatement = null;
		try {
			prepSqlStatement = connection.prepareStatement(sqlStatement);
			prepSqlStatement.setInt(1, memberID);
			int rowCount = prepSqlStatement.executeUpdate();
			if (rowCount != 1){
				result = false; 
				System.out.println("\nMember ID entered does not exist");
			} 
			else {
				result = true;
				System.out.println("\nMember deleted!\n");
			}
		}
		catch (SQLException ex){
			ex.printStackTrace();
			result = false;
		}
		return result;
	}		
	
//UPDATE MEMBER_______________________________________________________________________________________________________	
	/*
	  * update existing member row;
	  * parameter (member) contains all the data for the DB row; the object can
	  * contain existing data and/or new data; it is up to the application class
	  * to determine what data is in this object; this class just updates
	  * every column in the table except the primary key column (Member_ID); you can't update
	  * the primary key column; if you want to do that you need to delete the old
	  * row and add a new row with the corrected Member_ID;
	  * Return true on success, false on failure; should probably throw an exception
	  * if row not updated but keeping it simple.
	  */
	public boolean updateMember(member member) {

		boolean result = false; 
		String sqlStatement = 
				new String("UPDATE worship_member SET LastName = ?, FirstName = ?,  Address = ?, City = ?, Phone = ?, Role = ? "); 
		sqlStatement += " WHERE Member_ID = ?";
		PreparedStatement prepSqlStatement = null;
		try {
			prepSqlStatement = connection.prepareStatement(sqlStatement);
			//prepSqlStatement.setInt(1, member.getMember_ID());
			prepSqlStatement.setString(1, member.getLastName());
			prepSqlStatement.setString(2, member.getFirstName());
			prepSqlStatement.setString(3, member.getAddress());
			prepSqlStatement.setString(4, member.getCity());
			prepSqlStatement.setInt(5, member.getPhone());
			prepSqlStatement.setInt(6, member.getRole());
			prepSqlStatement.setInt(7, member.getMember_ID());
			
			int rowCount = prepSqlStatement.executeUpdate();
			if (rowCount != 1){
				result = false; //should throw exception but keeping it simple	
			}
			else {
				result = true;
			}
		} catch (SQLException ex) {
			ex.printStackTrace();
			result = false;
		}	
		return result;
	}	
	
//FIND MEMBER_______________________________________________________________________________________________________	
	/*
	  * query (retrieve) existing member row;
	  * the parameter (Member_ID) contains the primary key value used to select the specific
	  * rows to retrieve;
	  * Return Member object created using data from the found DB row on success, null on failure; 
	  * should probably throw an exception if row not found but keeping it simple.
	  */
	public member findMember(int Member_ID) {
		String sqlStatement = new String("SELECT * FROM worship_member WHERE Member_ID = ?"); 
		PreparedStatement prepSqlStatement = null;
		ResultSet rsFindMembers = null;
		member memberTransferObject = null;
		try{
			prepSqlStatement = connection.prepareStatement(sqlStatement);
			prepSqlStatement.setInt(1, Member_ID);
			rsFindMembers = prepSqlStatement.executeQuery();
			if (rsFindMembers == null) { //the member wasn't found
				return null;
			}
			while (rsFindMembers.next()){
				int tempMember_ID = rsFindMembers.getInt(1);
				String tempLastName = rsFindMembers.getString(2);
				String tempFirstName = rsFindMembers.getString(3);
				String tempAddress = rsFindMembers.getString(4);
				String tempCity = rsFindMembers.getString(5);
				int tempPrice = rsFindMembers.getInt(6);
				int tempRole = rsFindMembers.getInt(7);
				
				memberTransferObject = new member(tempMember_ID, tempLastName, tempFirstName, 
						tempAddress, tempCity, tempPrice, tempRole);
			}
		}
		catch (SQLException ex){
			ex.printStackTrace();
		}
		return memberTransferObject;
	}	
	
	
	 /*
	  * query (retrieve) all member rows;
	  * Return a collection of Member objects created using data from the found DB rows on success, 
	  * null on failure; 
	  */
//QUERY ALL MEMBERS_______________________________________________________________________________________________________
	public Collection<member> selectAllMembers() {
		List<member> memberList = new ArrayList<member>(); 
		String sqlStatement = new String("SELECT * FROM worship_member"); 
		PreparedStatement prepSqlStatement = null;
		ResultSet rsFindMembers = null;
		try{
			prepSqlStatement = connection.prepareStatement(sqlStatement);
			rsFindMembers = prepSqlStatement.executeQuery();
			while (rsFindMembers.next()){
				int tempMemberID = rsFindMembers.getInt(1);
				String tempLastName = rsFindMembers.getString(2);
				String tempFirst = rsFindMembers.getString(3);
				String tempAddress = rsFindMembers.getString(4);
				String tempCity = rsFindMembers.getString(5);
				int tempPhone = rsFindMembers.getInt(6);
				int tempRole = rsFindMembers.getInt(7);
				
				memberList.add(new member(tempMemberID, tempLastName, tempFirst, 
						tempAddress, tempCity, tempPhone, tempRole));
			}
			return memberList;  //method succeeded so return collection of books that were found
		}
		catch (SQLException ex){
			ex.printStackTrace();
		}
		return null; //method failed so return null
	}	
}