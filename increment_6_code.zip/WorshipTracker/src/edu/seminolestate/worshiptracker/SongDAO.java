package edu.seminolestate.worshiptracker;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.Collection;
import java.util.List;

public class SongDAO {

private static Connection connection;
	
	public SongDAO(){
		connection = DbConnection.getConnection();
	}
		
//INSERT SONG_________________________________________________________________________________________________________	
		public boolean insertSong(songs songs) {

			boolean result = false; 
			String sqlStatement = new String("INSERT INTO songs (Song_Title, Composer, Song_Key, Length) VALUES (?, ?, ?, ?)"); 
			PreparedStatement prepSqlStatement = null;
			try {
				prepSqlStatement = connection.prepareStatement(sqlStatement);
				prepSqlStatement.setString(1, songs.getSong_Title());
				prepSqlStatement.setString(2, songs.getComposer());
				prepSqlStatement.setString(3, songs.getSong_Key());
				prepSqlStatement.setDouble(4, songs.getLength());
				//prepSqlStatement.setInt(5, songs.getTotal_Count());
				int rowCount = prepSqlStatement.executeUpdate();
				if (rowCount != 1){
					result =  false; 
				}
				else {
						result = true;
				}
			} catch (SQLException ex) {
				// TODO Auto-generated catch block
				ex.printStackTrace();
				result =  false;
			}	
			return result; 
		}
		
	
//DELETE SONG_______________________________________________________________________________________________________	
		public boolean deleteSong(String Song_Title) {

			boolean result = false; 
			String sqlStatement = new String("DELETE FROM songs WHERE Song_Title = ?"); 
			PreparedStatement prepSqlStatement = null;
			try {
				prepSqlStatement = connection.prepareStatement(sqlStatement);
				prepSqlStatement.setString(1, Song_Title);
				int rowCount = prepSqlStatement.executeUpdate();
				if (rowCount != 1){
					result = false; //should throw exception
				} 
				else {
					result = true;
				}
			}
			catch (SQLException ex){
				ex.printStackTrace();
				result = false;
			}
			return result;
		}		

//UPDATE SONG_______________________________________________________________________________________________________		
		public boolean updateSong(songs songs) {

			boolean result = false; 
			String sqlStatement = 
					new String("UPDATE songs SET Composer = ?, Song_Key = ?,  Length = ? "); 
			sqlStatement += " WHERE Song_Title = ?";
			PreparedStatement prepSqlStatement = null;
			try {
				prepSqlStatement = connection.prepareStatement(sqlStatement);
				//prepSqlStatement.setString(1, songs.getSong_Title());
				prepSqlStatement.setString(1, songs.getComposer());
				prepSqlStatement.setString(2, songs.getSong_Key());
				prepSqlStatement.setDouble(3, songs.getLength());
				prepSqlStatement.setString(4, songs.getSong_Title());
				
				int rowCount = prepSqlStatement.executeUpdate();
				if (rowCount != 1){
					result = false; //should throw exception but keeping it simple	
				}
				else {
					result = true;
				}
			} catch (SQLException ex) {
				ex.printStackTrace();
				result = false;
			}	
			return result;
		}			
		
		
//FIND SONG_______________________________________________________________________________________________________	
		public songs findSong(String Song_Title) {
			String sqlStatement = new String("SELECT * FROM songs WHERE Song_Title = ?"); 
			PreparedStatement prepSqlStatement = null;
			ResultSet rsFindSongs = null;
			songs songTransferObject = null;
			try{
				prepSqlStatement = connection.prepareStatement(sqlStatement);
				prepSqlStatement.setString(1, Song_Title);
				rsFindSongs = prepSqlStatement.executeQuery();
				if (rsFindSongs == null) { //the song wasn't found
					return null;
				}
				while (rsFindSongs.next()){
					String tempSong_Title = rsFindSongs.getString(1);
					String tempComposer = rsFindSongs.getString(2);
					String tempSong_Key = rsFindSongs.getString(3);
					Double tempLength = rsFindSongs.getDouble(4);
					int tempTotal_Count = rsFindSongs.getInt(5);
					
					songTransferObject = new songs(tempSong_Title, tempComposer, tempSong_Key, 
							tempLength, tempTotal_Count);
				}
			}
			catch (SQLException ex){
				ex.printStackTrace();
			}
			return songTransferObject;
		}		
		
		
//QUERY ALL SONGS_______________________________________________________________________________________________________
		public Collection<songs> selectAllSongs() {
			List<songs> songList = new ArrayList<songs>(); 
			String sqlStatement = new String("SELECT * FROM songs"); 
			PreparedStatement prepSqlStatement = null;
			ResultSet rsFindSongs = null;
			try{
				prepSqlStatement = connection.prepareStatement(sqlStatement);
				rsFindSongs = prepSqlStatement.executeQuery();
				while (rsFindSongs.next()){
					String tempSong_Title = rsFindSongs.getString(1);
					String tempComposer = rsFindSongs.getString(2);
					String tempSong_Key = rsFindSongs.getString(3);
					Double tempLength = rsFindSongs.getDouble(4);
					int tempTotal_Count = rsFindSongs.getInt(5);
						
					songList.add(new songs(tempSong_Title, tempComposer, tempSong_Key, tempLength, tempTotal_Count));
				}
				return songList;  //method succeeded so return collection of songs that were found
			}
			catch (SQLException ex){
				ex.printStackTrace();
			}
			return null; //method failed so return null
		}		
}
