package edu.seminolestate.worshiptracker;

import java.sql.Connection;
import java.sql.Date;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
//import java.sql.ResultSet;
import java.sql.SQLException;
//import java.util.ArrayList;
//import java.util.Collection;
//import java.util.List;
import java.time.LocalDate;
import java.util.ArrayList;
import java.util.Collection;
import java.util.List;

public class ScheduleDAO {

	private static Connection connection;
	
	public ScheduleDAO(){
		connection = DbConnection.getConnection();
	}
	
	//INSERT SCHEDULE_______________________________________________________________________________________________________
		public boolean insertSchedule(schedule schedule) {

			boolean result = false; 
			String sqlStatement = new String("INSERT INTO schedule (Worship_Date, Song_Title, Member_ID, Role_ID) VALUES (?, ?, ?, ?)"); 
			PreparedStatement prepSqlStatement = null;
			try {
				prepSqlStatement = connection.prepareStatement(sqlStatement);
				prepSqlStatement.setDate(1, Date.valueOf(schedule.getWorship_Date()));
				prepSqlStatement.setString(2, schedule.getSong_Title());
				prepSqlStatement.setInt(3, schedule.getMember_ID());
				prepSqlStatement.setInt(4, schedule.getRole_ID());
				int rowCount = prepSqlStatement.executeUpdate();
				if (rowCount != 1){
					result =  false; 
				}
				else {
						result = true;
						System.out.println("\nNew Schedule added!\n");
				}
			} catch (SQLException ex) {
				// TODO Auto-generated catch block
				ex.printStackTrace();
				result =  false;
			}	
			return result; 
		}
		
	//DELETE SCHEDULE_______________________________________________________________________________________________________	
			public boolean deleteSchedule(LocalDate Worship_Date) {

				boolean result = false; 
				String sqlStatement = new String("DELETE FROM schedule WHERE Worship_Date = ?"); 
				PreparedStatement prepSqlStatement = null;
				try {
					prepSqlStatement = connection.prepareStatement(sqlStatement);
					prepSqlStatement.setDate(1, Date.valueOf(Worship_Date));
					int rowCount = prepSqlStatement.executeUpdate();
					if (rowCount < 1){
						result = false; 
						System.out.println("Schedule Date entered does not exist\n");
					} 
					else {
						result = true;
						System.out.println("\nSchedule deleted!\n");
					}
				}
				catch (SQLException ex){
					ex.printStackTrace();
					result = false;
				}
				return result;
			}				
		
	//UPDATE SCHEDULE_______________________________________________________________________________________________________		
			public boolean updateSchedule(schedule schedule) {

				boolean result = false; 
				String sqlStatement = 
						new String("UPDATE schedule SET Song_Title = ?, Member_ID = ?,  Role_ID = ? "); 
				sqlStatement += " WHERE Schedule_ID = ?";
				PreparedStatement prepSqlStatement = null;
				try {
					prepSqlStatement = connection.prepareStatement(sqlStatement);
					prepSqlStatement.setString(1, schedule.getSong_Title());
					prepSqlStatement.setInt(2, schedule.getMember_ID());
					prepSqlStatement.setInt(3, schedule.getRole_ID());
					prepSqlStatement.setInt(4, schedule.getSchedule_ID());
					
					int rowCount = prepSqlStatement.executeUpdate();
					if (rowCount != 1){
						result = false; //should throw exception 
					}
					else {
						result = true;
					}
				} catch (SQLException ex) {
					ex.printStackTrace();
					result = false;
				}	
				return result;
			}			
			
			
			
	//FIND SCHEDULE_______________________________________________________________________________________________________
		public schedule findScheduleID(int Schedule_ID) {
			String sqlStatement = new String("SELECT * FROM schedule WHERE Schedule_ID = ?"); 
			PreparedStatement prepSqlStatement = null;
			ResultSet rsFindSchedule = null;
			schedule scheduleTransferObject = null;
			try{
				prepSqlStatement = connection.prepareStatement(sqlStatement);
				prepSqlStatement.setInt(1, Schedule_ID);
				rsFindSchedule = prepSqlStatement.executeQuery();
				if (rsFindSchedule == null) { //the role wasn't found
					return null;
				}
				while (rsFindSchedule.next()){
					int tempScheduleID = rsFindSchedule.getInt(1);
					java.sql.Date tempWorshipDate = rsFindSchedule.getDate(2);
					//Convert SQL date to LocalDate
					LocalDate tempWorshipDateLocalDate = tempWorshipDate.toLocalDate();
					String tempSongTitle = rsFindSchedule.getString(3);
					int tempMemberID = rsFindSchedule.getInt(4);
					int tempRoleID = rsFindSchedule.getInt(5);
					
					scheduleTransferObject = new schedule(tempScheduleID, tempWorshipDateLocalDate, tempSongTitle, tempMemberID, tempRoleID);
				}
			}
			catch (SQLException ex){
				ex.printStackTrace();
			}
			return scheduleTransferObject;
		}			
		
		
	//FIND SCHEDULE_______________________________________________________________________________________________________
			public schedule findSchedule(LocalDate Worship_Date) {
				String sqlStatement = new String("SELECT * FROM schedule WHERE Worship_Date = ?"); 
				PreparedStatement prepSqlStatement = null;
				ResultSet rsFindSchedule = null;
				schedule scheduleTransferObject = null;
				try{
					prepSqlStatement = connection.prepareStatement(sqlStatement);
					prepSqlStatement.setDate(1, Date.valueOf(Worship_Date));
					rsFindSchedule = prepSqlStatement.executeQuery();
					if (rsFindSchedule == null) { //the role wasn't found
						return null;
					}
					while (rsFindSchedule.next()){
						int tempScheduleID = rsFindSchedule.getInt(1);
						java.sql.Date tempWorshipDate = rsFindSchedule.getDate(2);
						//Convert SQL date to LocalDate
						LocalDate tempWorshipDateLocalDate = tempWorshipDate.toLocalDate();
						String tempSongTitle = rsFindSchedule.getString(3);
						int tempMemberID = rsFindSchedule.getInt(4);
						int tempRoleID = rsFindSchedule.getInt(5);
							
						scheduleTransferObject = new schedule(tempScheduleID, tempWorshipDateLocalDate, tempSongTitle, tempMemberID, tempRoleID);
					}
				}
				catch (SQLException ex){
					ex.printStackTrace();
				}
				return scheduleTransferObject;
			}		
			
			
	//QUERY WORSHIP DATES_______________________________________________________________________________________________________
		public Collection<schedule> selectedSchedule(LocalDate Worship_Date) {
			List<schedule> scheduleList = new ArrayList<schedule>(); 
			String sqlStatement = new String("SELECT * FROM schedule WHERE Worship_Date= ?"); 
			PreparedStatement prepSqlStatement = null;
			ResultSet rsFindSchedule = null;
			try{
				prepSqlStatement = connection.prepareStatement(sqlStatement);
				prepSqlStatement.setDate(1, Date.valueOf(Worship_Date));
				rsFindSchedule = prepSqlStatement.executeQuery();
				if (rsFindSchedule == null) { //the Date wasn't found
					return null;
				}
				while (rsFindSchedule.next()){
					int tempScheduleID = rsFindSchedule.getInt(1);
					java.sql.Date tempWorshipDate = rsFindSchedule.getDate(2);
					//Convert SQL date to LocalDate
					LocalDate tempWorshipDateLocalDate = tempWorshipDate.toLocalDate();
					String tempSongTitle = rsFindSchedule.getString(3);
					int tempMemberID = rsFindSchedule.getInt(4);
					int tempRoleID = rsFindSchedule.getInt(5);
							
					scheduleList.add(new schedule(tempScheduleID, tempWorshipDateLocalDate, tempSongTitle, tempMemberID, tempRoleID));
				}
				return scheduleList;  //method succeeded so return collection of Worship Dates that were found
			}
			catch (SQLException ex){
				ex.printStackTrace();
			}
			return null; //method failed so return null
		}	
		
	//QUERY SCHEDULE IDs_______________________________________________________________________________________________________
			public Collection<schedule> scheduleID(LocalDate Worship_Date) {
				List<schedule> scheduleList = new ArrayList<schedule>(); 
				String sqlStatement = new String("SELECT Schedule_ID FROM schedule WHERE Worship_Date= ?"); 
				PreparedStatement prepSqlStatement = null;
				ResultSet rsFindSchedule = null;
				try{
					prepSqlStatement = connection.prepareStatement(sqlStatement);
					prepSqlStatement.setDate(1, Date.valueOf(Worship_Date));
					rsFindSchedule = prepSqlStatement.executeQuery();
					if (rsFindSchedule == null) { //the Date wasn't found
						return null;
					}
					while (rsFindSchedule.next()){
						int tempScheduleID = rsFindSchedule.getInt(1);
									
						scheduleList.add(new schedule(tempScheduleID));
					}
					return scheduleList;  //method succeeded so return collection of IDs that were found
				}
				catch (SQLException ex){
					ex.printStackTrace();
				}
				return null; //method failed so return null
			}	

	//QUERY ALL SCHEDULES_______________________________________________________________________________________________________
			public Collection<schedule> selectAllSchedules() {
				List<schedule> scheduleList = new ArrayList<schedule>(); 
				String sqlStatement = new String("SELECT * FROM schedule"); 
				PreparedStatement prepSqlStatement = null;
				ResultSet rsFindSchedule = null;
				try{
					prepSqlStatement = connection.prepareStatement(sqlStatement);
					rsFindSchedule = prepSqlStatement.executeQuery();
					while (rsFindSchedule.next()){
						int tempScheduleID = rsFindSchedule.getInt(1);
						java.sql.Date tempWorshipDate = rsFindSchedule.getDate(2);
						//Convert SQL date to LocalDate
						LocalDate tempWorshipDateLocalDate = tempWorshipDate.toLocalDate();
						String tempSongTitle = rsFindSchedule.getString(3);
						int tempMemberID = rsFindSchedule.getInt(4);
						int tempRoleID = rsFindSchedule.getInt(5);
							
						scheduleList.add(new schedule(tempScheduleID, tempWorshipDateLocalDate, tempSongTitle, tempMemberID, tempRoleID));
					}
					return scheduleList;  //method succeeded so return collection of songs that were found
				}
				catch (SQLException ex){
					ex.printStackTrace();
				}
				return null; //method failed so return null
			}			
			
	
}
