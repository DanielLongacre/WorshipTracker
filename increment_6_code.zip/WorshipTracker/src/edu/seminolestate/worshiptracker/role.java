package edu.seminolestate.worshiptracker;

import java.time.LocalDate;

public class role {
	//MEMBER VARIABLES:
			private int Role_ID;
			private String Description;
			private LocalDate StartDate;
			private LocalDate EndDate;
			
			//CONSTRUCTOR:
			public role (int newRole_ID, String newDescription, LocalDate newStartDate, LocalDate newEndDate) {
				this.Role_ID = newRole_ID;
				this.Description = newDescription;
				this.StartDate = newStartDate;
				this.EndDate = newEndDate;
			}
			
			//GETTERS AND SETTERS:
			public int getRole_ID() {
				return Role_ID;
			}
			public void setRole_ID(int role_ID) {
				this.Role_ID = role_ID;
			}
			public String getDescription() {
				return Description;
			}
			public void setDescription(String description) {
				this.Description = description;
			}
			public LocalDate getStartDate() {
				return StartDate;
			}
			public void setStartDate(LocalDate startDate) {
				this.StartDate = startDate;
			}
			public LocalDate getEndDate() {
				return EndDate;
			}
			public void setEndDate(LocalDate endDate) {
				this.EndDate = endDate;
			}

			//ToString METHOD:
			@Override
			public String toString() {
				return "role [Role_ID=" + Role_ID + ", Description=" + Description + ", StartDate=" + StartDate
						+ ", EndDate=" + EndDate + "]";
			}
			
}
