package edu.seminolestate.worshiptracker;

import java.time.LocalDate;

public class schedule {
	//MEMBER VARIABLES:
		private int Schedule_ID;
		private LocalDate Worship_Date;
		private String Song_Title;
		private int Member_ID;
		private int Role_ID;
		
	//CONSTRUCTOR:
		public schedule(int newSchedule_ID, LocalDate newWorship_Date, 
				String newSong_Title, int newMember_ID, int newRole_ID) {
			this.Schedule_ID = newSchedule_ID;
			this.Worship_Date = newWorship_Date;
			this.Song_Title = newSong_Title;
			this.Member_ID = newMember_ID;
			this.Role_ID = newRole_ID;
		}
		
		public schedule(LocalDate newWorship_Date, 
				String newSong_Title, int newMember_ID, int newRole_ID) {
			this.Worship_Date = newWorship_Date;
			this.Song_Title = newSong_Title;
			this.Member_ID = newMember_ID;
			this.Role_ID = newRole_ID;
		}
		
		public schedule(int newScheduleID) {
			this.Schedule_ID = newScheduleID;
		}

	//GETTERS AND SETTERS:	
		public int getSchedule_ID() {
			return Schedule_ID;
		}

		public void setSchedule_ID(int schedule_ID) {
			Schedule_ID = schedule_ID;
		}

		public LocalDate getWorship_Date() {
			return Worship_Date;
		}

		public void setWorship_Date(LocalDate worship_Date) {
			this.Worship_Date = worship_Date;
		}

		public String getSong_Title() {
			return Song_Title;
		}

		public void setSong_Title(String song_Title) {
			Song_Title = song_Title;
		}

		public int getMember_ID() {
			return Member_ID;
		}

		public void setMember_ID(int member_ID) {
			Member_ID = member_ID;
		}

		public int getRole_ID() {
			return Role_ID;
		}

		public void setRole_ID(int role_ID) {
			Role_ID = role_ID;
		}
	
	//ToString METHOD:
		@Override
		public String toString() {
			return "schedule [Schedule_ID=" + Schedule_ID + ", Worship_Date=" 
					+ Worship_Date + ", Song_Title=" + Song_Title
					+ ", Member_ID=" + Member_ID + ", Role_ID=" + Role_ID
					+ "]";
		}
	
}
