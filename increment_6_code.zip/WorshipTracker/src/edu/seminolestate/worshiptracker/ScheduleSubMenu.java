package edu.seminolestate.worshiptracker;

import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
//import java.util.ArrayList;
import java.util.Scanner;

public class ScheduleSubMenu {

	private static Scanner scanner = new Scanner(System.in);
	
	public static void main() {
		
		int subMenuChoice = 0;
		
		//SUBMENU OPTIONS
		while(subMenuChoice != 5) {
			subMenuChoice = getScheduleSubMenuChoice();
			switch (subMenuChoice) {
			case 1: //ADD SCHEDULE
				ScheduleDAO scheduleDAO = new ScheduleDAO(); //call constructor to create DB connection
				//ScheduleDAO searchSchedule = ScheduleDAO.findSchedule();
				SongDAO findSong = new SongDAO();
				WorshipDAO findMember = new WorshipDAO();
				RoleDAO findRole = new RoleDAO();
				
				//Prompt for the Schedule Info
				//Does the date exists?
				LocalDate userWorshipDate = getDate("Enter Worship Date(MM/DD/YYYY): ");
				String userSong_Title = getString("Enter a Song Title: ");
				//Check to see if Song exists
				songs searchSongs = findSong.findSong(userSong_Title);
				if ( searchSongs == null) {
					System.out.println("That Song was not found");
					break;
				}
				int userMember_ID = getMemberInteger("Enter the Member ID of the person leading this song: ");
				//Check to see if member exists
				member searchMember = findMember.findMember(userMember_ID);
				if ( searchMember == null) {
					System.out.println("That Member was not found\n");
					break;
				}
				int userRole_ID = getRoleInteger("Enter a Role number(1-6) for that member: ");
				//Check to see if role exists
				role roleSearch = findRole.findRole(userRole_ID);
				if (roleSearch == null) {
					System.out.println("That Role was not found\n");
					break;
				}
				
				try {
				//Create Schedule and insert into the database
				schedule schedule = new schedule(userWorshipDate, userSong_Title, userMember_ID, userRole_ID);
				scheduleDAO.insertSchedule(schedule);
				
				} catch (Exception e) {
					System.out.println("Invalid Entry. Please try again.");
				}
				break;
				
			case 2: //DELETE SCHEDULE
				ScheduleDAO deleteSchedule = new ScheduleDAO(); //Call constructor to create DB connection
				ScheduleDAO whichSchedule = new ScheduleDAO(); //Call constructor to create DB connection
				//ScheduleDAO findSchedule = new ScheduleDAO();
				
				//Ask the user to choose a Schedule to delete by Worship_Date
				LocalDate userDeleteSchedule = getDate("\n\nEnter Worship Date to delete(MM/DD/YYYY): ");
				//Check to see if Date Exists
				ArrayList<schedule> listSchedule = (ArrayList<schedule>)whichSchedule.selectedSchedule(userDeleteSchedule);
				if (listSchedule.size() == 0) {
					System.out.println("That Worship Date was not found\n");
				} else {
					deleteSchedule.deleteSchedule(userDeleteSchedule);
					System.out.println("\n");
				}
				break;
				
			case 3: //CHANGE SCHEDULE
				ScheduleDAO scheduleChange = new ScheduleDAO(); 
				ScheduleDAO list = new ScheduleDAO();
				ScheduleDAO find = new ScheduleDAO();
				
				LocalDate userChangeSchedule = getDate("\n\nEnter Worship Date to change(MM/DD/YYYY): ");
				//Check to see if Worship Date exists
				schedule change = scheduleChange.findSchedule(userChangeSchedule);
				ArrayList<schedule> displaySchedule = (ArrayList<schedule>)list.selectedSchedule(userChangeSchedule);
				if (displaySchedule.size() == 0) {
					System.out.println("That Worship Date was not found\n");
					break;
				} else {
					displayAllFormatted(displaySchedule);
					System.out.println("\n");
				}
				
				//Choose Schedule ID to update from the list
				int searchWorshipID = getWorshipIDInteger("\n\nEnter Schedule ID for the schedule to update: ");
				//Check to see if Schedule exists
				schedule searchSchedule = find.findScheduleID(searchWorshipID); 
				if ( searchSchedule == null) {
					System.out.println("That Schedule was not found");
					break;
				}
				//else...
					
				
				//Song Title
				System.out.println("Current Song_Title is " + searchSchedule.getSong_Title() + 
						". Enter new Song_Title or Enter key to skip.");
				String newTitle = scanner.nextLine();
				if (newTitle.length() > 0) {
					searchSchedule.setSong_Title(newTitle);
				} //else leave original value in place
				
				//Member ID
				System.out.println("Current Member_ID is " + searchSchedule.getMember_ID() + 
						". Enter new Member_ID or Enter key to skip.");
				String newID = scanner.nextLine();
				if (newID.length() > 0) {
					try {
						int newMemID = Integer.parseInt(newID);
						searchSchedule.setMember_ID(newMemID);
					} catch (NumberFormatException e) {
						System.out.println("Invalid Entry. Please enter a valid integer.");
					}
				} else {
					searchSchedule.setMember_ID(change.getMember_ID());
				}
				
				//Role ID
				System.out.println("Current Role_ID is " + searchSchedule.getRole_ID() + 
						". Enter new Role_ID or Enter key to skip.");
				String newRole = scanner.nextLine();
				if (newRole.length() > 0) {
					try {
						int newRoleID = Integer.parseInt(newRole);
						searchSchedule.setRole_ID(newRoleID);
					} catch (NumberFormatException e) {
						System.out.println("Invalid Entry. Please enter a valid integer.");
					}
				} else {
					searchSchedule.setRole_ID(change.getRole_ID());
				}
				
				boolean isSuccessful = scheduleChange.updateSchedule(searchSchedule);
				if (isSuccessful) {
					System.out.println("\nSchedule Updated!");
				} else { 
					System.out.println("\nThat Schedule was not Updated.");
				}
				
				break;
				
			case 4: //SELECT SCHEDULE
				ScheduleDAO scheduleSelect = new ScheduleDAO(); //Call constructor to create DB connection
				
				LocalDate selectSchedule = getDate("\nEnter Worship Date to display it's schedule(MM/DD/YYYY): ");
				//Display all Worship Dates that match that input
				ArrayList<schedule> scheduleList = (ArrayList<schedule>)scheduleSelect.selectedSchedule(selectSchedule);
				
				//Check to see if Worship Date exists
				if (scheduleList.size() == 0) {
					System.out.println("The Schedule for that Worship Date was not found\n");
				} else {
					displayAllFormatted(scheduleList);
					System.out.println("\n");
				}
				break;
				
			case 5: // EXIT
				break;
				
			default: //Invalid Menu choice was entered
				System.out.println("Invalid menu choice. Choose from the options displayed.\n");
				break;
			}
			
			
		}
		
	}

	//MENU_______________________________________________________________________________________________________________
		public static int getScheduleSubMenuChoice() {
			int userResponse = 0;

			String userInput;
			System.out.println("\nSchedule Menu: ");
			System.out.println("1. Add Schedule");
			System.out.println("2. Delete Schedule");
			System.out.println("3. Change Schedule");
			System.out.println("4. Select Schedule");
			System.out.println("5. Exit to Main Menu");
			userInput = scanner.nextLine();
			if (userInput == null || userInput.equals("")) {// if no input ...
				return 99;
			}
			userResponse = Integer.parseInt(userInput);
			return userResponse;
		}
		
	//INPUT AND ERRORS_______________________________________________________________________________________________________________		
		//FOR DATE ENTRY
		public static LocalDate getDate(String prompt) {
			String input = null;
			LocalDate tempDate = null;
			do {
				System.out.print(prompt);
				input = scanner.nextLine();
				try {
					if (input == null || input == "") {
						System.out.println("Can't leave this blank.\n");
					} else {
						DateTimeFormatter formatter = DateTimeFormatter.ofPattern("M/d/yyyy");
						tempDate = LocalDate.parse(input, formatter);
					} 
				} catch (Exception e) {
					System.out.println("Invalid Format. Please try again.\n");
					return getDate(prompt);
				} 
			} while (input == null || input == "");
			
			return tempDate;
		}
	
		//FOR STRING ENTRY  
		public static String getString(String prompt) {
			String input = null;
			while (input == null) {
				System.out.print(prompt);
				input = scanner.nextLine();
				if (input == null || input == "") {
					System.out.println("Invalid Entry. Please reenter.");
					System.out.print(prompt);
					input = scanner.nextLine();
				}
			}
			return input;
		}	
		
		//FOR MEMBER INTEGER ENTRY
		public static int getMemberInteger(String prompt) {
			int userInt = 0;
			do {
				try {
					System.out.print(prompt);
					String userValue = scanner.nextLine();
					userInt = Integer.parseInt(userValue);
					if (userInt <= 0) {
						System.out.println("Value must be > 0. Please reenter.");
						}
					}
				catch (NumberFormatException e) {
					System.out.println("Invalid Entry. Please reenter.");
					return getMemberInteger(prompt);
					}
			} while (userInt <= 0);

			return userInt;
		}
		
		//FOR ROLE INTEGER ENTRY
		public static int getRoleInteger(String prompt) {
			int userInt = 0;
			do {
				try {
					System.out.print(prompt);
					String userValue = scanner.nextLine();
					userInt = Integer.parseInt(userValue);
					if (userInt <= 0) {
						System.out.println("Value must be greater than 0. Please reenter.");
						}
					}
				catch (NumberFormatException e) {
					System.out.println("Invalid Entry. Value must be greater than 0. Please reenter.");
					return getRoleInteger(prompt);
					}
			} while (userInt <= 0);

			return userInt;
		}
		
		//FOR WORSHIP ID ENTRY
		public static int getWorshipIDInteger(String prompt) {
			int userInt = 0;
			do {
				try {
					System.out.print(prompt);
					String userValue = scanner.nextLine();
					userInt = Integer.parseInt(userValue);
					if (userInt <= 0) {
						System.out.println("Value must be > 0. Please reenter.");
						}
					}
				catch (NumberFormatException e) {
					System.out.println("Invalid Entry. Please reenter.");
					}
			} while (userInt <= 0);

			return userInt;
		}		

		
		//DISPLAY ALL SCHEDULES_______________________________________________________________________________________________________________
		public static void displayAllFormatted (ArrayList<schedule> scheduleList) {
			System.out.printf("\n%-12s %-20s %-25s %-10s %-10s", 
					"Schedule_ID", "Worship_Date", "Song_Title", "Member_ID", "Role_ID");
			System.out.printf("\n%-12s %-20s %-25s %-10s %-10s", 
					"-----------", "----------------", "---------", "---------", "---------");
			for (schedule aSchedule : scheduleList) {
				System.out.printf("\n%-12s %-20s %-25s %-10s %-10s", 
						aSchedule.getSchedule_ID(),
						aSchedule.getWorship_Date(),
						aSchedule.getSong_Title(),
						aSchedule.getMember_ID(),
						aSchedule.getRole_ID());
				
			}
		}		
		
}
