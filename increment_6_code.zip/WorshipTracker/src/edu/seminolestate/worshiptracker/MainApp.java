package edu.seminolestate.worshiptracker;

import java.util.Scanner;

public class MainApp {

	private static Scanner scanner = new Scanner(System.in);
	
	public static void main(String[] args) {
		System.out.println("Welcome to the Worship Tracker App!");
		//Initialize the menu choice
				int menuChoice = 0;
				
				//MAIN MENU OPTIONS
				while (menuChoice != 5) { // continue to loop until user enters 4 (exit)
					menuChoice = getMenuChoice();
					switch (menuChoice) {
					case 1: //MEMBER SUBMENU
						MemberSubMenu.main();
						break;
						
					case 2: //ROLE SUBMENU
						RoleSubMenu.main();
						break;
						
					case 3: //SONGS SUBMENU
						SongsSubMenu.main();
						break;
						
					case 4: //SCHEDULE SUBMENU	
						ScheduleSubMenu.main();
						break;
						
					case 5: //EXIT
						System.out.println("\nThanks for using the Worship Tracker App!");
						break;
						
					default: //INVALID MENU CHOICE WAS ENTERED
						System.out.println("Invalid menu choice. Choose from the options displayed.\n");
						break;
					}	
				}

	}
//_______________________________________________________________________________________________________________	
	
	//MENU
	public static int getMenuChoice() {
		int userResponse = 0;

		String userInput;
		System.out.println("\nMAIN MENU\nChoose from the options below: ");
		System.out.println("1. Members");
		System.out.println("2. Roles");
		System.out.println("3. Songs");
		System.out.println("4. Schedule");
		System.out.println("5. Exit");
		userInput = scanner.nextLine();
		if (userInput == null || userInput.equals("")) {// if no input ...
			return 99;
		}
		userResponse = Integer.parseInt(userInput);
		return userResponse;
	}
	
}
