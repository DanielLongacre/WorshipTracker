package edu.seminolestate.worshiptracker;

import java.sql.Connection;
import java.sql.Date;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.time.LocalDate;
import java.util.ArrayList;
import java.util.Collection;
import java.util.List;


public class RoleDAO {
	
	private static Connection connection;
	
	public RoleDAO(){
		connection = DbConnection.getConnection();
	}
		
//INSERT ROLE_________________________________________________________________________________________________________	
		public boolean insertRole(role role) {

			boolean result = false; 
			String sqlStatement = new String("INSERT INTO role (Role_ID, Description, Start_Date) VALUES (?, ?, ?)"); 
			PreparedStatement prepSqlStatement = null;
			try {
				prepSqlStatement = connection.prepareStatement(sqlStatement);
				prepSqlStatement.setInt(1, role.getRole_ID());
				prepSqlStatement.setString(2, role.getDescription());
				prepSqlStatement.setDate(3, Date.valueOf(role.getStartDate()));
				//prepSqlStatement.setDate(4, Date.valueOf(role.getEndDate()));
				int rowCount = prepSqlStatement.executeUpdate();
				if (rowCount != 1){
					result =  false; 
				}
				else {
					result = true;
					System.out.println("\nNew Role added!\n");
				}
			} catch (SQLException ex) {
				// TODO Auto-generated catch block
				ex.printStackTrace();
				result =  false;
			}	
			return result; 
		}

//DELETE ROLE_______________________________________________________________________________________________________	
	public boolean deleteRole(int roleID) {

		boolean result = false; 
		String sqlStatement = new String("DELETE FROM role WHERE Role_ID = ?"); 
		PreparedStatement prepSqlStatement = null;
		try {
			prepSqlStatement = connection.prepareStatement(sqlStatement);
			prepSqlStatement.setInt(1, roleID);
			int rowCount = prepSqlStatement.executeUpdate();
			if (rowCount != 1){
				result = false;
				System.out.println("Role ID entered does not exist\n");
			} 
			else {
				result = true;
				System.out.println("\nRole deleted!\n");
			}
		}
		catch (SQLException ex){
			ex.printStackTrace();
			result = false;
		}
		return result;
	}		
	
//UPDATE ROLE_______________________________________________________________________________________________________	
	public boolean updateRole(role role) {

		boolean result = false; 
		String sqlStatement = 
				new String("UPDATE role SET Description = ?, Start_Date = ? "); 
		sqlStatement += " WHERE Role_ID = ?";
		PreparedStatement prepSqlStatement = null;
		try {
			prepSqlStatement = connection.prepareStatement(sqlStatement);
			//prepSqlStatement.setInt(1, role.getRole_ID());
			prepSqlStatement.setString(1, role.getDescription());
			prepSqlStatement.setDate(2, Date.valueOf(role.getStartDate()));
			//prepSqlStatement.setDate(4, Date.valueOf(role.getEndDate()));
			prepSqlStatement.setInt(3, role.getRole_ID());
			
			int rowCount = prepSqlStatement.executeUpdate();
			if (rowCount != 1){
				result = false; //should throw exception but keeping it simple	
			}
			else {
				result = true;
			}
		} catch (SQLException ex) {
			ex.printStackTrace();
			result = false;
		}	
		return result;
	}		
	
	
//FIND ROLE_______________________________________________________________________________________________________
	public role findRole(int Role_ID) {
		String sqlStatement = new String("SELECT * FROM role WHERE Role_ID = ?"); 
		PreparedStatement prepSqlStatement = null;
		ResultSet rsFindRoles = null;
		role roleTransferObject = null;
		try{
			prepSqlStatement = connection.prepareStatement(sqlStatement);
			prepSqlStatement.setInt(1, Role_ID);
			rsFindRoles = prepSqlStatement.executeQuery();
			if (rsFindRoles == null) { //the role wasn't found
				return null;
			}
			while (rsFindRoles.next()){
				int tempRoleID = rsFindRoles.getInt(1);
				String tempDescription = rsFindRoles.getString(2);
				java.sql.Date tempStartDate = rsFindRoles.getDate(3);
				//Convert SQL date to LocalDate
				LocalDate tempStartDateLocalDate = tempStartDate.toLocalDate();
				
				roleTransferObject = new role(tempRoleID, tempDescription, tempStartDateLocalDate, null);
			}
		}
		catch (SQLException ex){
			ex.printStackTrace();
		}
		return roleTransferObject;
	}	
	
	
//CHECK TO SEE IF ROLE ALREADY EXISTS___________________________________________________________________________________
	public boolean roleExists(int roleID) {
		boolean result = false;
		String sqlStatement = new String("SELECT * FROM role WHERE Role_ID = ?");
		PreparedStatement prepSqlStatement = null;
		try {
			prepSqlStatement = connection.prepareStatement(sqlStatement);
			prepSqlStatement.setInt(1, roleID);
			int rsFindRole = prepSqlStatement.executeUpdate();
			if (rsFindRole == 1) {
				result = true;
			} else {
				result = false;
			}
		} catch (SQLException ex){
			System.out.println("This Role ID already exists\n");
			result = true;
		} 
		return result;
	}
	
//QUERY ALL ROLES_______________________________________________________________________________________________________
	public Collection<role> selectAllRoles() {
		List<role> roleList = new ArrayList<role>(); 
		String sqlStatement = new String("SELECT * FROM role"); 
		PreparedStatement prepSqlStatement = null;
		ResultSet rsFindRoles = null;
		try{
			prepSqlStatement = connection.prepareStatement(sqlStatement);
			rsFindRoles = prepSqlStatement.executeQuery();
			while (rsFindRoles.next()){
				int tempRoleID = rsFindRoles.getInt(1);
				String tempDescription = rsFindRoles.getString(2);
				java.sql.Date tempStartDate = rsFindRoles.getDate(3);
				//Convert SQL date to LocalDate
				LocalDate tempStartDateLocalDate = tempStartDate.toLocalDate();		
				//java.sql.Date tempEndDate = rsFindRoles.getDate(4);
				//Convert SQL date to LocalDate
				//LocalDate tempEndDateLocalDate = tempEndDate.toLocalDate();
					
				roleList.add(new role(tempRoleID, tempDescription, tempStartDateLocalDate, null));
			}
			return roleList;  //method succeeded so return collection of roles that were found
		}
		catch (SQLException ex){
			ex.printStackTrace();
		}
		return null; //method failed so return null
	}	
		
}
