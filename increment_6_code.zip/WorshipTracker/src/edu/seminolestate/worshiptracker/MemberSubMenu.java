package edu.seminolestate.worshiptracker;

import java.util.ArrayList;
import java.util.Scanner;


public class MemberSubMenu {
	
	private static Scanner scanner = new Scanner(System.in);
	
	public static void  main() {
		int subMenu1Choice = 0;
		
		//SUBMENU OPTIONS
		while (subMenu1Choice != 5) { // continue to loop until user enters 4 (exit)
			subMenu1Choice = getMemberSubMenuChoice();
			switch (subMenu1Choice) {
			case 1: //ADD MEMBER
		
				WorshipDAO worshipDAO = new WorshipDAO();//call constructor to create DB connection
				
				//Prompt for the Member info
				String userMemberLName = getString("\nEnter Last Name: ");
				String userMemberFName = getString("Enter First Name: ");
				String userMemberAddress = getString("Enter Address: ");
				String userMemberCity = getString("Enter City: ");
				int userMemberPhone = getPhoneInteger("Enter Phone number (without area code): ");
				int userMemberRole = getRoleInteger("Enter Role number: ");
				
				//Create member and insert into database
				member member = new member(userMemberLName, userMemberFName, userMemberAddress, userMemberCity, userMemberPhone, userMemberRole);
				worshipDAO.insertMember(member);
				
				//Confirm member added
				System.out.println("\nNew Member added!");
				break;
			case 2: //DELETE MEMBER
				WorshipDAO worshipDAOshow = new WorshipDAO();//call constructor to create DB connection
				WorshipDAO worshipDAODelete = new WorshipDAO(); //call constructor to create DB connection
				
				//Display all members so the user can choose the appropriate Member ID to delete
				ArrayList<member> memberList = (ArrayList<member>)worshipDAOshow.selectAllMembers();
				if (memberList != null) {
					System.out.println("\nMember List");
					displayAllFormatted(memberList);
				} else {
					System.out.println("Currently, there are no members");
				}
				
				//Ask user to choose Member to delete by ID
				int userDeleteMemberID = getMemberInteger("\n\nEnter Member ID to delete: ");
				worshipDAODelete.deleteMember(userDeleteMemberID);
			
				break;
			case 3: //CHANGE MEMBER
				WorshipDAO worshipDAOchange = new WorshipDAO();//call constructor to create DB connection
				
				System.out.println("\nMake sure to enter the information correctly. Any invalid entries will return you to the Member Menu.");
				int searchMember_ID = getMemberInteger("Enter Member ID for the member to update: ");
				//Check to see if member exists
				member searchMember = worshipDAOchange.findMember(searchMember_ID);
				if ( searchMember == null) {
					System.out.println("That Member was not found\n");
					break;
				} 
				//else...
				//CHOOSE WHICH FIELDS TO UPDATE
				
				//Last Name
				System.out.println("Current Last Name is " + searchMember.getLastName() + 
						". Enter new Last Name or Enter key to skip.");
				String newLast = scanner.nextLine();
				if (newLast.length() > 0) {
					searchMember.setLastName(newLast);
				} //else leave original value in place
				
				//First Name
				System.out.println("Current First Name is " + searchMember.getFirstName() + 
						". Enter new First Name or Enter key to skip.");
				String newFirst = scanner.nextLine();
				if (newFirst.length() > 0) {
					searchMember.setFirstName(newFirst);
				} //else leave original value in place
				
				//Address
				System.out.println("Current Address is " + searchMember.getAddress() + 
						". Enter new First Name or Enter key to skip.");
				String newAddress = scanner.nextLine();
				if (newAddress.length() > 0) {
					searchMember.setAddress(newAddress);
				} //else leave original value in place
				
				//City
				System.out.println("Current City is " + searchMember.getCity() + 
						". Enter new City or Enter key to skip.");
				String newCity = scanner.nextLine();
				if (newCity.length() > 0) {
					searchMember.setCity(newCity);
				} //else leave original value in place
				
				//Phone
				System.out.println("Current Phone is " + searchMember.getPhone() + 
						". Enter new Phone or Enter key to skip.");
				String userPhone = scanner.nextLine();				
				if (userPhone.length() > 0) {
					try {
						int newPhone = Integer.parseInt(userPhone);
						if (newPhone < 1000000 || newPhone > 10000000) {
							System.out.println("Invalid Entry. Phone must be 7 digits. Please reenter.");
							break;
						}
						searchMember.setPhone(newPhone);
					} catch (NumberFormatException e) {
						System.out.println("Invalid Entry. Phone must be 7 digits.");
						break;
						}
				} //else leave original value in place
				
				//Role
				System.out.println("Current Role is " + searchMember.getRole() + 
						". Enter new Role or Enter key to skip.");
				String newRole = scanner.nextLine();
				if (newRole.length() > 0) {
					try {
						int newRoleInt = Integer.parseInt(newRole);
						if (newRoleInt < 1 || newRoleInt > 6) {
							System.out.println("Invalid Entry. Value must be between 1-6.");
							break;
						}
						searchMember.setRole(newRoleInt);
					} catch (NumberFormatException e) {
						System.out.println("Invalid Entry. Value must be between 1-6. Please reenter.");
						break;
						}  
				} //else leave original value in place
				
				boolean isSuccessful = worshipDAOchange.updateMember(searchMember);
				if (isSuccessful) {
					System.out.println("\nMember Updated!");
				} else { 
					System.out.println("\nThat Member was not Updated.");
				}
				
				break;
			case 4: //SELECT MEMBER
				WorshipDAO worshipDAOselect = new WorshipDAO();//call constructor to create DB connection
				
				int memberIDSearch = getMemberInteger("\nEnter Member ID to display: ");
				//Check to see if member exists
				member memberSearch = worshipDAOselect.findMember(memberIDSearch);
				if ( memberSearch == null) {
					System.out.println("That Member was not found\n");
					break;
				} else {
				displayMember(memberSearch);
				}
				
				break;
			case 5: //EXIT
				break;
			default: //Invalid menu choice was entered
				System.out.println("Invalid menu choice. Choose from the options displayed.\n");
				break;
			}
		}
		return;
	}

//MENU_______________________________________________________________________________________________________________
	public static int getMemberSubMenuChoice() {
		int userResponse = 0;

		String userInput;
		System.out.println("\nMember Menu: ");
		System.out.println("1. Add Member");
		System.out.println("2. Delete Member");
		System.out.println("3. Change Member");
		System.out.println("4. Select Member");
		System.out.println("5. Exit to Main Menu");
		userInput = scanner.nextLine();
		if (userInput == null || userInput.equals("")) {// if no input ...
			return 99;
		}
		userResponse = Integer.parseInt(userInput);
		return userResponse;
	}
//INPUT AND ERRORS______________________________________________________________________________________________________	
	//FOR STRING ENTRY  
		public static String getString(String prompt) {
			String input = null;
			while (input == null) {
				System.out.print(prompt);
				input = scanner.nextLine();
				if (input == null || input == "") {
					System.out.println("Invalid Entry. Please reenter.");
					System.out.print(prompt);
					input = scanner.nextLine();
				}
			}
			return input;
		}
		
		//FOR PHONE INTEGER ENTRY
			public static int getPhoneInteger(String prompt) {
				int userInt = 0;
				do {
					try {
						System.out.print(prompt);
						String userValue = scanner.nextLine();
						userInt = Integer.parseInt(userValue);
						if (userInt < 1000000 || userInt >= 10000000) {
							System.out.println("Value must be 7 digits. Please reenter.");
							}
						}
					catch (NumberFormatException e) {
						System.out.println("Invalid Entry. Phone must be 7 digits. Please reenter.");
						}
				} while (userInt < 1000000 || userInt >= 10000000);

				return userInt;
			}
			
			//FOR ROLE INTEGER ENTRY
			public static int getRoleInteger(String prompt) {
				int userInt = 0;
				do {
					try {
						System.out.print(prompt);
						String userValue = scanner.nextLine();
						userInt = Integer.parseInt(userValue);
						if (userInt < 1 || userInt > 6) {
							System.out.println("Value must be between 1-6. Please reenter.");
							}
						}
					catch (NumberFormatException e) {
						System.out.println("Invalid Entry. Value must be between 1-6. Please reenter.");
						}
				} while (userInt < 1 || userInt > 6);

				return userInt;
			}
			
			//FOR MEMBER INTEGER ENTRY
			public static int getMemberInteger(String prompt) {
				int userInt = 0;
				do {
					try {
						System.out.print(prompt);
						String userValue = scanner.nextLine();
						userInt = Integer.parseInt(userValue);
						if (userInt <= 0) {
							System.out.println("Value must be > 0. Please reenter.");
							}
						}
					catch (NumberFormatException e) {
						System.out.println("Invalid Entry. Please reenter.");
						}
				} while (userInt <= 0);

				return userInt;
			}

//DISPLAY MEMBER_______________________________________________________________________________________________________________			
			public static void displayMember(member member) {
				System.out.println("\n*************************");
				System.out.println(member.getMember_ID());
				System.out.println(member.getLastName() + ", " + member.getFirstName());
				System.out.println(member.getAddress() + ", " + member.getCity() + ", " + member.getPhone());
				System.out.println(member.getRole());
				System.out.println("*************************\n");
			}			
			
//DISPLAY ALL MEMBERS__________________________________________________________________________________________________________
			/*
			 * Method displays all the member rows from the DB. The print method is used to space
			 * the data into columns with heading.
			 */
			public static void displayAllFormatted (ArrayList<member> memberList) {
				System.out.printf("\n%-10s %-15s %-15s %-25s %-10s %-10s %-10s", 
						"Member_ID", "LastName", "FirstName", "Address", "City", "Phone", "Role");
				System.out.printf("\n%-10s %-15s %-15s %-25s %-10s %-10s %-10s", 
						"----------", "----------", "-----------", "----------", "---------", "------", "------");
				for (member aMember : memberList) {
					System.out.printf("\n%-10s %-15s %-15s %-25s %-10s %-10s %-10s", 
							aMember.getMember_ID(),
							aMember.getLastName(),
							aMember.getFirstName(),
							aMember.getAddress(),
							aMember.getCity(),
							aMember.getPhone(),
							aMember.getRole());
				}
			}			
			
			
}
