package edu.seminolestate.worshiptracker;

import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.Scanner;

public class RoleSubMenu {
	
	private static Scanner scanner = new Scanner(System.in);
	
	public static void  main() {
		
		int subMenu1Choice = 0;
		
		//SUBMENU OPTIONS
		while (subMenu1Choice != 5) { // continue to loop until user enters 5 (exit)
			subMenu1Choice = getRoleSubMenuChoice();
			switch (subMenu1Choice) {
			case 1: //ADD ROLE
				RoleDAO roleDAOshow = new RoleDAO(); //Call constructor to create DB connection
				RoleDAO roleDAO = new RoleDAO();//call constructor to create DB connection
				
				//Display all roles so the user can choose the appropriate Role ID to add
				ArrayList<role> roleList = (ArrayList<role>)roleDAOshow.selectAllRoles();
				if (roleList != null) {
					System.out.println("\nRole List");
					displayAllFormatted(roleList);
				} else {
					System.out.println("Currently, there are no roles");
				}
				
				//Prompt for the Role info
				int userRole_ID = getRoleInteger("\nEnter new Role number: ");
				String userDescription = getString("Enter Description: ");
				LocalDate userStartDate = getDate("Enter Start Date(MM/DD/YYYY): ");
				//LocalDate userEndDate = getDate("Enter End Date(MM/DD/YYYY): ");
				
				//Create role and insert into database
				role role = new role(userRole_ID, userDescription, userStartDate, null);
				roleDAO.insertRole(role);
				
				break;
			case 2: //DELETE ROLE
				RoleDAO roleDAOshow2 = new RoleDAO(); //Call constructor to create DB connection
				RoleDAO roleDelete = new RoleDAO(); //call constructor to create DB connection
				
				//Display all roles so the user can choose the appropriate Role ID to delete
				ArrayList<role> roleList2 = (ArrayList<role>)roleDAOshow2.selectAllRoles();
				if (roleList2 != null) {
					System.out.println("\nRole List");
					displayAllFormatted(roleList2);
				} else {
					System.out.println("Currently, there are no roles");
				}
				
				//Ask user to choose Role to delete by Role ID
				int userDeleteRoleID = getRoleInteger("\n\nEnter Role ID to delete: ");
				roleDelete.deleteRole(userDeleteRoleID);
				
				break;
			case 3: //CHANGE ROLE
				RoleDAO roleDAOchange = new RoleDAO();
				RoleDAO roleDAOList = new RoleDAO();
				
				//Display all roles so the user can choose the appropriate Role ID to delete
				ArrayList<role> roleList3 = (ArrayList<role>)roleDAOList.selectAllRoles();
				if (roleList3 != null) {
					System.out.println("\nRole List");
					displayAllFormatted(roleList3);
				} else {
					System.out.println("Currently, there are no roles");
				}
				
				int searchRole_ID = getRoleInteger("\n\nEnter Role ID for the role to update: ");
				//Check to see if role exists
				role searchRole = roleDAOchange.findRole(searchRole_ID);
				if (searchRole == null) {
					System.out.println("That Role was not found\n");
					break;
				}
				//else...
				//CHOOSE WHICH FIELDS TO UPDATE
				
				//Description
				System.out.println("Current Description is " + searchRole.getDescription() + 
						". Enter new Description or Enter key to skip.");
				String newDescription = scanner.nextLine();
				if (newDescription.length() > 0) {
					searchRole.setDescription(newDescription);
				} //else leave original value in place
				
				//Start Date
				DateTimeFormatter dtf = DateTimeFormatter.ofPattern("M/d/yyyy"); 
				System.out.println("Current Start Date is " + searchRole.getStartDate() + 
						". Enter new Start Date (mm/dd/yyyy) or Enter key to skip that field.");
				String newStartDate = scanner.nextLine();
				try {
					if (newStartDate.length() > 0) {
						LocalDate newStartDateLocalDate = LocalDate.parse(newStartDate, dtf);
						searchRole.setStartDate(newStartDateLocalDate);
					} 
				} catch (Exception e) {
					System.out.println("Invalid Entry. Please enter date in MM/DD/YYYY format");
					break;
				} //else leave original value in place
				
				//End Date
				DateTimeFormatter dtf2 = DateTimeFormatter.ofPattern("M/d/yyyy"); 
				System.out.println("Current End Date is " + searchRole.getEndDate() + 
						". Enter new End Date (mm/dd/yyyy) or Enter key to skip that field.");
				String newEndDate = scanner.nextLine();
				try {
					if (newEndDate.length() > 0) {
						LocalDate newEndDateLocalDate = LocalDate.parse(newEndDate, dtf2);
						searchRole.setEndDate(newEndDateLocalDate);
					} 
				} catch (Exception e) {
					System.out.println("Invalid Entry. Please enter date in MM/DD/YYYY format");
					break;
				} //else leave original value in place
				
				boolean isSuccessful = roleDAOchange.updateRole(searchRole);
				if (isSuccessful) {
					System.out.println("\nRole Updated!");
				} else { 
					System.out.println("\nThat Role was not Updated.");
				}
				
				break;
			case 4: //SELECT MEMBER
				RoleDAO roleDAOSelect = new RoleDAO(); //Call constructor to create DB connection
				
				int role_IDSearch = getRoleInteger("\n\nEnter Role ID to display: ");
				//Check to see if role exists
				role roleSearch = roleDAOSelect.findRole(role_IDSearch);
				if (roleSearch == null) {
					System.out.println("That Role was not found\n");
					break;
				} else {
					displayRole(roleSearch);
				}
				
				break;
			case 5: //EXIT
				break;
			default: //Invalid menu choice was entered
				System.out.println("Invalid menu choice. Choose from the options displayed.\n");
				break;	
			}
		}
	}
	
//MENU_______________________________________________________________________________________________________________
	public static int getRoleSubMenuChoice() {
		int userResponse = 0;

		String userInput;
		System.out.println("\nRole Menu: ");
		System.out.println("1. Add Role");
		System.out.println("2. Delete Role");
		System.out.println("3. Change Role");
		System.out.println("4. Select Role");
		System.out.println("5. Exit to Main Menu");
		userInput = scanner.nextLine();
		if (userInput == null || userInput.equals("")) {// if no input ...
			return 99;
		}
		userResponse = Integer.parseInt(userInput);
		return userResponse;
	}
	
//INPUT AND ERRORS_______________________________________________________________________________________________________________	
	//FOR MEMBER ROLE INTEGER ENTRY
		public static int getRoleInteger(String prompt) {
			int userInt = 0;
			do {
				try {
					System.out.print(prompt);
					String userValue = scanner.nextLine();
					userInt = Integer.parseInt(userValue);
					if (userInt <= 0) {
						System.out.println("Value must be greater than 0. Please reenter.");
						}
					}
				catch (NumberFormatException e) {
					System.out.println("Invalid Entry. Value must be greater than 0. Please reenter.");
					}
			} while (userInt <= 0);

			return userInt;
		}	
				
	//FOR STRING ENTRY  
			public static String getString(String prompt) {
				String input = null;
				while (input == null) {
					System.out.print(prompt);
					input = scanner.nextLine();
					if (input == null || input == "") {
						System.out.println("Invalid Entry. Please reenter.");
						System.out.print(prompt);
						input = scanner.nextLine();
					}
				}
				return input;
			}
	
	//FOR DATE ENTRY
			public static LocalDate getDate(String prompt) {
				String input = null;
				LocalDate tempDate = null;
				while (input == null) {
					System.out.print(prompt);
					input = scanner.nextLine();
					if (input == null) {
						System.out.println("Can't leave this blank.");
					} else {
						DateTimeFormatter formatter = DateTimeFormatter.ofPattern("M/d/yyyy");
						tempDate = LocalDate.parse(input, formatter);
					}
				}
				return tempDate;
			}							

//DISPLAY ROLE_______________________________________________________________________________________________________________			
			public static void displayRole(role role) {
				System.out.println("\n*************************");
				System.out.println(role.getRole_ID());
				System.out.println(role.getDescription());
				System.out.println(role.getStartDate() + ", " + role.getEndDate());
				System.out.println("*************************\n");
			}			
			
//DISPLAY ALL ROLES_______________________________________________________________________________________________________________
			/*
			 * Method displays all the Role rows from the DB. The print method is used to space
			 * the data into columns with heading.
			 */
			public static void displayAllFormatted (ArrayList<role> roleList) {
				System.out.printf("\n%-10s %-20s %-15s %-10s", 
						"Role_ID", "Description", "Start_Date", "End_Date");
				System.out.printf("\n%-10s %-20s %-15s %-10s", 
						"----------", "----------------", "--------------", "-------------");
				for (role aRole : roleList) {
					System.out.printf("\n%-10s %-20s %-15s %-10s", 
							aRole.getRole_ID(),
							aRole.getDescription(),
							aRole.getStartDate(),
							aRole.getEndDate());
				}
			}			
			
}
