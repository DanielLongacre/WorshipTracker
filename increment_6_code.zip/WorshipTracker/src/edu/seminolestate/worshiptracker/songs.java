package edu.seminolestate.worshiptracker;

public class songs {
	//MEMBER VARIABLES:
			private String Song_Title;
			private String Composer; 
			private String Song_Key;
			private double length;
			private int Total_Count;
			
	//CONSTRUCTOR:
		public songs(String newSong_Title, String newComposer, String newSong_Key, double newlength, int newTotal_Count) {
			this.Song_Title = newSong_Title;
			this.Composer = newComposer;
			this.Song_Key = newSong_Key;
			this.length = newlength;
			this.Total_Count = newTotal_Count;
			}
		
		public songs(String newSong_Title, String newComposer, String newSong_Key, double newlength) {
			this.Song_Title = newSong_Title;
			this.Composer = newComposer;
			this.Song_Key = newSong_Key;
			this.length = newlength;
			}
		
	//GETTERS AND SETTERS
		public String getSong_Title() {
			return Song_Title;
		}

		public void setSong_Title(String song_Title) {
			Song_Title = song_Title;
		}

		public String getComposer() {
			return Composer;
		}

		public void setComposer(String composer) {
			Composer = composer;
		}

		public String getSong_Key() {
			return Song_Key;
		}

		public void setSong_Key(String song_Key) {
			Song_Key = song_Key;
		}

		public double getLength() {
			return length;
		}

		public void setLength(double length) {
			this.length = length;
		}

		public int getTotal_Count() {
			return Total_Count;
		}

		public void setTotal_Count(int total_Count) {
			Total_Count = total_Count;
		}
	
	//ToString METHOD:
			@Override
			public String toString() {
				return "songs [Song_Title=" + Song_Title + ", Composer=" + Composer + ", Song_Key=" + Song_Key
						+ ", Length=" + length + ", Total_Count=" + Total_Count + "]";
			}	
}
